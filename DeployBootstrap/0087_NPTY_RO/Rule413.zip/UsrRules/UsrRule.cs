namespace RO.UsrRules
{
	public class UsrRule {} 
}
